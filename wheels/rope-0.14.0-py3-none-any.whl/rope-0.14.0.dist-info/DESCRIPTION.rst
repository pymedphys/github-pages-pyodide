

.. _GitHub python-rope / rope: https://github.com/python-rope/rope


========================================
 rope, a python refactoring library ...
========================================


Overview
========

`Rope`_ is a python refactoring library.

.. _`rope`: https://github.com/python-rope/rope


Notes
============

* Nick Smith <nicks@fastmail.fm> takes over maintaining rope. Many thanks to
  Matej Cepl for his work maintaining rope for the past few years!!
* Partial Python3 support, please file bugs and contribute patches if you
  encounter gaps.



